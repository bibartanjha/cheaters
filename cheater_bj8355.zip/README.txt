To compile the program,type in "make" to the command prompt.To run the program,
type "./plagiarismCatcher path/to/files number(n) number(minimum collisions)"
For the "path/to/files",make sure the directory is in the proper spot.For the 
number n, you must type in a number bigger than 0(single digit is preferabbly).
For the minimum number of collisions,a number greater than 100 is preferabble.
